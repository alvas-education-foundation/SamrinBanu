<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-11-29 07:11:20 --> You must enable php_gmp to use Bitauth.
ERROR - 2019-11-29 07:11:36 --> You must enable php_gmp to use Bitauth.
ERROR - 2019-11-29 07:15:36 --> 404 Page Not Found --> clinic
ERROR - 2019-11-29 07:15:44 --> 404 Page Not Found --> clinic
ERROR - 2019-11-29 07:15:50 --> 404 Page Not Found --> clinic
ERROR - 2019-11-29 07:15:57 --> You must enable php_gmp to use Bitauth.
ERROR - 2019-11-29 07:18:00 --> You must enable php_gmp to use Bitauth.
ERROR - 2019-11-29 07:40:55 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2019-11-29 07:41:33 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2019-11-29 08:03:01 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:03:18 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:03:31 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:03:35 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:03:59 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:04:53 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:06:45 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:10:32 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:12:00 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:14:04 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 08:14:53 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:03:01 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:03:08 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:05:39 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:06:58 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:11:44 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:11:57 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:11:59 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:12:04 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:12:08 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:12:10 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:12:16 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:12:18 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:13:32 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:13:37 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:13:46 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:13:48 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 09:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\ticket.php 19
ERROR - 2019-11-29 09:15:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\ticket.php 19
ERROR - 2019-11-29 09:16:52 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:17:54 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:18:06 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 09:19:48 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:45:19 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:45:53 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 09:46:46 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:47:13 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:47:17 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:48:20 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 09:48:29 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 09:56:35 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 09:56:41 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 09:57:28 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 09:58:08 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:01:57 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:02:08 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:06:53 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:06:55 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:07:05 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:07:08 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:21 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:11:23 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:27 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:29 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:33 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:35 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:11:41 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:11:44 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:13:39 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:13:41 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:13:43 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:13:45 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:13:48 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:14:03 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:14:08 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:14:14 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:14:16 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:17:37 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:23:47 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:23:55 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:24:00 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:24:06 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:24:07 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:24:09 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:26:45 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:26:47 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:26:52 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:26:58 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:27:45 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:27:52 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:27:57 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:27:59 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:31:14 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:31:16 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:31:18 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:34:24 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:34:27 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:34:29 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:34:33 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:34:37 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:34:39 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:34:42 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:34:43 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:34:47 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:38:40 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:39:29 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:39:35 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:40:23 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:40:37 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:40:40 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:41:13 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:41:32 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:41:35 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:09 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:42:10 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:42:25 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:42:28 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:31 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:35 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:38 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:39 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:42:42 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:43:32 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:43:34 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:43:48 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:44:13 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:44:26 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:45:11 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:45:15 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:45:19 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:45:30 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:45:34 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:45:41 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:45:51 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:46:05 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:46:22 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:46:32 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:46:38 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:04 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:07 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:20 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:35 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:42 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:45 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:47:54 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:48:20 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:48:23 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:48:28 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:48:32 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:48:34 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:48:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 10:48:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 10:49:03 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:49:04 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:49:06 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:49:08 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:49:27 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:49:33 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:00 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:17 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:19 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:22 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:26 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:30 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:50:32 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:50:35 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:50:43 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:50:52 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:51:16 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:51:35 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:51:36 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:51:45 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:51:49 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:51:59 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:52:03 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:52:08 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:52:24 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:52:38 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:52:58 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:53:00 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:53:06 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:53:08 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:53:13 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:53:16 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:55:06 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:55:10 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\ticket.php 19
ERROR - 2019-11-29 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\ticket.php 19
ERROR - 2019-11-29 10:55:58 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:56:00 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:56:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:56:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:56:23 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:56:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 10:56:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 10:56:46 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:56:48 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 10:56:55 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:56:57 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 10:57:01 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:57:03 --> 404 Page Not Found --> test/alvas.png
ERROR - 2019-11-29 10:57:06 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 10:57:39 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 10:58:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:11 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:58:13 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:58:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:16 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:58:18 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 10:58:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 10:58:20 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:20 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:07:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:07:25 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:27 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:30 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:07:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:07:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:07:36 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:38 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:48 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:07:50 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:02 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:08:05 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:08:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:07 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:08:13 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:09:43 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:09:46 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 11:09:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 11:14:41 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:14:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:14:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:14:46 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:14:50 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:15:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 11:15:46 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 11:18:48 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:18:57 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 11:19:14 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 11:47:07 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:47:19 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:47:22 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 11:47:29 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:47:31 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 11:54:42 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:54:57 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 11:55:37 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:32:00 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:32:07 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:35:14 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:36:59 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:42:15 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:43:54 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:44:14 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:44:32 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 13:44:50 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:45:04 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 13:52:45 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:52:46 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:52:51 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:12 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:53:15 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:29 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:39 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:41 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:43 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:53:44 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:54:53 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:54:55 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:55:40 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:55:43 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:55:48 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 13:55:53 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:56:44 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:56:46 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 13:56:52 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:56:55 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 13:57:10 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:57:39 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 13:57:41 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 13:57:54 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:57:56 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:57:58 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:58:30 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:58:35 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:59:37 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 13:59:59 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:00:11 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:00:26 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:00:29 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:00:36 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:00:43 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:01:21 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 14:01:23 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 14:01:49 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 14:01:50 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 14:01:55 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 14:01:57 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 14:01:58 --> 404 Page Not Found --> xray/alvas.png
ERROR - 2019-11-29 14:02:01 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 14:02:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 14:02:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\waiting.php 34
ERROR - 2019-11-29 14:02:48 --> 404 Page Not Found --> patient/alvas.png
ERROR - 2019-11-29 14:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 14:02:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\some\application\views\patient\panel.php 52
ERROR - 2019-11-29 14:03:59 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 14:06:25 --> 404 Page Not Found --> account/alvas.png
ERROR - 2019-11-29 14:06:34 --> 404 Page Not Found --> alvas.png
ERROR - 2019-11-29 14:06:38 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 14:07:25 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 14:07:32 --> 404 Page Not Found --> drug/alvas.png
ERROR - 2019-11-29 14:07:36 --> 404 Page Not Found --> alvas.png
