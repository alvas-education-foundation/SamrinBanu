<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-11-28 17:56:05 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'clinic' C:\xampp\htdocs\Clinic\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2019-11-28 17:56:05 --> Unable to connect to the database
ERROR - 2019-11-28 17:59:16 --> You must enable php_gmp to use Bitauth.
